/* freebsd9 is a superset of freebsd8 */
#include "freebsd8.h"
#define freebsd8 freebsd8
